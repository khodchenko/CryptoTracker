package com.example.cryptotraker

import android.os.Bundle
import androidx.fragment.app.Fragment

class CryptoPage : Fragment(R.layout.fragment_crypto_page) {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView:
    }

}